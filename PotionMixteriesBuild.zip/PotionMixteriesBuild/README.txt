Welcome to Potion Mixteries!

This game has been build with the UI Accessibility Plugin Version 1.1.1 for Unity. The plugin should automatically detect active accessibility services and enable itself. Otherwise, the accessibility features will be disabled by default.

The plugin's documentation can be found here:
http://www.metalpopgames.com/assetstore/accessibility/doc/index.html